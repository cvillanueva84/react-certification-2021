const AUTH_STORAGE_KEY = 'wa_cert_authenticated';

export { AUTH_STORAGE_KEY };
