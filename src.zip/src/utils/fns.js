function random(limit) {
  return Math.floor(Math.random() * limit);
}

export { random };
