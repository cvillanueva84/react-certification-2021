export { default } from './Home.page';
