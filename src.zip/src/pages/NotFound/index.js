export { default } from './NotFound.page';
