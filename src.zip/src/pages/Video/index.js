export { default } from './Video.page';
