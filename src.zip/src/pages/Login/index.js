export { default } from './Login.page';
