export { default } from './Secret.page';
