export { default } from './Card.component';
