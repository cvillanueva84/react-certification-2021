export { default } from './Main.component';
