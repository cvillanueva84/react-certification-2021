export { default } from './Video.component';
