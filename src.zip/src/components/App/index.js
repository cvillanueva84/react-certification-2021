export { default } from './App.component';
