export { default } from './videoPlayer.component';
